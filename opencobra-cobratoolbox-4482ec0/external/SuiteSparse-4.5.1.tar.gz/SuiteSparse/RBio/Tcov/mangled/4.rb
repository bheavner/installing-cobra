row indices truncated
             3             1             1             1
iua                        4             4            16             0
(26I3)          (40I2)          (26I3)              
  1  5  9 13 17
 1 2 3 4 1 2 3 4 1
